import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from '../../../services/auth';
 
@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './register.html',
  styleUrls: ['./register.scss']
})
export class Register {
  username = '';
  email = '';
  password = '';
  role = ''; 
 
  loading = false;
  errorMessage = '';
 
  constructor(private authService: AuthService, private router: Router) {}
 
  register() {
    this.errorMessage = '';
 
    if (!this.username || !this.email || !this.password || !this.role) {
      this.errorMessage = 'Please fill out all fields including role.';
      return;
    }
 
    this.loading = true;
 
    this.authService.register({
      username: this.username,
      email: this.email,
      password: this.password,
      role: this.role   //  send role to backend!!!!!!!!!!!!!!!!!!!!!!
    }).subscribe({
      next: () => {
        this.loading = false;
        alert('Registration successful! Please login.');
        this.router.navigate(['/login']);
      },
      error: (err) => {
        this.loading = false;
        console.error('Registration error:', err);
        this.errorMessage = err.error?.message || 'Server error. Please try again.';
      }
    });
  }
}