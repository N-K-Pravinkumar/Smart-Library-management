import { Component } from '@angular/core';
import { AuthService } from '../../../services/auth';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
 
@Component({
  selector: 'app-login',
  templateUrl: './login.html',
  styleUrls: ['./login.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule],
})
export class Login {
  email = '';
  password = '';
  username = '';
  loading = false;
  errorMessage = '';
 
  constructor(private authService: AuthService, private router: Router) {}
 
  login(form: NgForm) {
    this.errorMessage = '';
 
    if (form.invalid) {
      form.control.markAllAsTouched();
      return;
    }
 
    this.loading = true;
 
    this.authService.login({ email: this.email, password: this.password }).subscribe({
      next: (res) => {
        this.loading = false;
 
        localStorage.setItem('token', res.token || '');
        localStorage.setItem('username', res.username || '');
        const role = res.role?.toLowerCase() || '';
        localStorage.setItem('role', role);
  
        if (role === 'student' && res.id != null) {
          localStorage.setItem('userId', res.id.toString());
          this.router.navigateByUrl('/student/home');
        } else if (role === 'librarian') {
          this.router.navigateByUrl('/librarian/home');
        } else {
          alert('Unknown user role received from server');
        }
      },
      error: (err) => {
        this.loading = false;
        this.errorMessage =
          err?.status === 401
            ? 'Invalid email or password'
            : 'Server error. Please try again later.';
      },
    });
  }
 
  goToRegister() {
    this.router.navigateByUrl('/register');
  }
}